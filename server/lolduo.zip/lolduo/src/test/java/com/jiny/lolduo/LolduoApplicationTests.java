package com.jiny.lolduo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LolduoApplicationTests {

	@Test
	void contextLoads() {
	}

}
