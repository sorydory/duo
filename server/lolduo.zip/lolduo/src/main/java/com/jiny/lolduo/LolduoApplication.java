package com.jiny.lolduo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LolduoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LolduoApplication.class, args);
	}

}
